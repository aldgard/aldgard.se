README



=== TESTS ===

Google Page Speed Insight -- Gav inte så bra optimeringsresultat. 77 på mobilenhet och 52 på desktop. Dock ingen page speed tillgänglig.
Google Chrome Audit -- 